#ifndef STUDENTWORLD_H_
#define STUDENTWORLD_H_

#include "GameWorld.h"
#include <string>
#include <list>

class Actor;
class Socrates;


// Students:  Add code to this file, StudentWorld.cpp, Actor.h, and Actor.cpp


class StudentWorld : public GameWorld
{
public:
    StudentWorld(std::string assetPath);
    virtual int init();
    virtual int move();
    virtual void cleanUp();
    
    virtual ~StudentWorld();
    
    //public helper functions
    Socrates* getSocrates() const;
    
    bool iscollidingSocrates(const Actor* a) const;
    
    bool iscollidingfoodorpit(const Actor* a) const;
    
    Actor* getcollidingenemy(const Actor* b) const;
    
    
private:
    
    //private members
    std::list<Actor*> m_actors;
    
    Socrates* m_socrates;
    
    int m_numenemieskilled;
    
    int m_targetkillcount;
    
    //private helperfunctions
    bool socrateswon();
    
    void removedeadobjects();
    
    void addnewactors();
    
    void updatedisplaytext();
    
    bool isWithinEuclidianDistance(const Actor* a, const Actor* b) const;
    
    
    
};

#endif // STUDENTWORLD_H_
