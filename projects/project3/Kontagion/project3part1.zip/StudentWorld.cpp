#include "StudentWorld.h"
#include "GameConstants.h"
#include <string>
#include <algorithm>
using namespace std;

#include <iostream>
#include <cmath>
#include <sstream>
#include "Actor.h"
#include <list>

GameWorld* createStudentWorld(string assetPath)
{
	return new StudentWorld(assetPath);
}

// Students:  Add code to this file, StudentWorld.h, Actor.h and Actor.cpp

StudentWorld::StudentWorld(string assetPath)
: GameWorld(assetPath)
{
    m_socrates = nullptr;
    m_numenemieskilled = 0;
    m_targetkillcount = 10 * (getLevel());
    
}

int StudentWorld::init()
{
    
    //add pits
    for (int i = 0; i < getLevel(); i++)
    {
        Pit* newpit = new Pit(this, randInt(0, VIEW_WIDTH-1), randInt(0, VIEW_HEIGHT-1));
        
        if (sqrt(pow(newpit->getX() - VIEW_WIDTH/2, 2) + pow(newpit->getY() - VIEW_HEIGHT/2, 2)) > 120 || iscollidingfoodorpit(newpit))
        {
            delete newpit;
            i--;
            continue;
        }
        
        m_actors.push_back(newpit);
    }
    
    //add food
    for (int i = 0; i < min(5*getLevel(), 25); i++)
    {
        //Food(StudentWorld* studentworld, double startX, double startY)
        Food* newfood = new Food(this, randInt(0, VIEW_WIDTH-1), randInt(0, VIEW_HEIGHT-1));
        
        if (sqrt(pow(newfood->getX() - VIEW_WIDTH/2, 2) + pow(newfood->getY() - VIEW_HEIGHT/2, 2)) > 120 || iscollidingfoodorpit(newfood))
        {

            delete newfood;
            i--;
            continue;
        }
        m_actors.push_back(newfood);
        
    }
    
    //add dirtpiles
    for (int i = 0; i < max(180-20*getLevel(), 20); i++)
    {
        //Dirt(StudentWorld* studentworld, double startX, double startY)
        Dirt* newdirt = new Dirt(this, randInt(0, VIEW_WIDTH-1), randInt(0, VIEW_HEIGHT-1));
        
        if (sqrt(pow(newdirt->getX() - VIEW_WIDTH/2, 2) + pow(newdirt->getY() - VIEW_HEIGHT/2, 2)) > 120 || iscollidingfoodorpit(newdirt))
        {
            delete newdirt;
            i--;
            continue;
        }
        
        m_actors.push_back(newdirt);
    }
    
    m_socrates = new Socrates(this);
    
    return GWSTATUS_CONTINUE_GAME;
}

int StudentWorld::move()
{

    if (m_socrates->isalive())
        m_socrates->doSomething();
    
//    list<Actor*>::iterator it = m_actors.begin();
    

//    while (it != m_actors.end())
//    {
//        // at every tick, check to see if the actors are alive, make them do something
//        if ((*it)->isalive())
//        {
//            (*it)->doSomething();

            //if socrates died as a result, end the level
//            if (!m_socrates->isalive())
//            {
//                decLives();
//                return GWSTATUS_PLAYER_DIED;
//            }
//            if (socrateswon())
//            {
//                advanceToNextLevel();
//
//                return GWSTATUS_PLAYER_WON;
//            }
//        }
//    }
    
    
    
    removedeadobjects();
    
//    addnewactors();
    
    updatedisplaytext();
    
    return GWSTATUS_CONTINUE_GAME;
}

void StudentWorld::cleanUp()
{
    if (m_socrates != nullptr)
    {
        delete m_socrates;
        m_socrates = nullptr;
    }
    list<Actor*>::iterator it = m_actors.begin();
    while (it != m_actors.end())
    {
        delete *it;
        m_actors.erase(it);
        it++;
    }
}

StudentWorld::~StudentWorld()
{
    cleanUp();
}

Socrates* StudentWorld::getSocrates() const
{
    return m_socrates;
}

bool StudentWorld::iscollidingSocrates(const Actor* a) const
{
    if (isWithinEuclidianDistance(a, getSocrates()))
    {
        return true;
    }
    return false;
}

bool StudentWorld::iscollidingfoodorpit(const Actor* a) const
{
    list<Actor*>::const_iterator it;
    
    for (it = m_actors.begin(); it != m_actors.end(); it++)
    {
        if((*it)->isfoodorpit() && isWithinEuclidianDistance(a, *it))
        {
            return true;
        }
    }
    
    return false;

}

Actor* StudentWorld::getcollidingenemy(const Actor* b) const
{
    list<Actor*>::const_iterator it;
    
    for (it = m_actors.begin(); it != m_actors.end(); it++)
    {
        if((*it)->isenemy() && isWithinEuclidianDistance(b, *it))
        {
            return *it;
        }
    }
    
    return nullptr;

}

///////////////////////
/////////PRIVATE FUNCTIONS/////
///////////////////////

bool StudentWorld::socrateswon()
{
    return (m_numenemieskilled == m_targetkillcount);
}

void StudentWorld::removedeadobjects()
{
    
    if (m_socrates != nullptr && ! m_socrates->isalive())
    {
        delete m_socrates;
        m_socrates = nullptr;
    }
    
    list<Actor*>::iterator it = m_actors.begin();
    while (it != m_actors.end())
    {
        if (! (*it)->isalive())
        {
            delete *it;
            m_actors.erase(it);
        }
        else
            it++;
    }
}

//void StudentWorld::addnewactors()
//{
//    int chancefungus = min(510- getLevel()*10, 200);
//
//    if (randInt(0, chancefungus) == 0)
//    {
//        Fungus* newfungus = new Fungus(this,
//    }
//}


void StudentWorld::updatedisplaytext()
{
    //if socrates is dead, return. dont update text
    if (getSocrates() == nullptr)
        return;
    
    ostringstream oss;
    
    oss << "Score: ";
    oss << getScore() << "  ";
    
    oss << "Level: ";
    oss << getLevel() << "  ";
    
    oss << "Lives: ";
    oss << getLives() << "  ";
    
    oss << "health: ";
    oss << getSocrates()->hp() << " ";
    
    oss << "Sprays: ";
    oss << getSocrates()->spraycharges() << " ";
    
    oss << "Flames: ";
    oss << getSocrates()->flamecharges();
    
    string result = oss.str();
    setGameStatText(result);
    
}

bool StudentWorld::isWithinEuclidianDistance(const Actor* a, const Actor* b) const
{
    int dx = a->getX() - b->getX();
    int dy = a->getY() - b->getY();
    double distance = sqrt(dx*dx + dy*dy);
    
    if (distance <= SPRITE_RADIUS*2)
    {
        return true;
    }
    return false;
}
