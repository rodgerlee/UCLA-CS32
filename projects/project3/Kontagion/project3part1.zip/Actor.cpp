#include <algorithm>

#include "Actor.h"
#include "StudentWorld.h"


// Students:  Add code to this file, Actor.h, StudentWorld.h, and StudentWorld.cpp

///////
//////Actor implementation///
//////

Actor::Actor(int imageID, double startX, double startY, Direction dir, int depth, double size, StudentWorld* studentworld)
: GraphObject(imageID, startX, startY, dir, depth, size)
{
    m_StudentWorld = studentworld;
    m_isalive = true;
}


    //set actor to alive by default.
bool Actor::isalive()
{
    return m_isalive;
}

    //sets actor to dead
void Actor::die()
{
    m_isalive = false;
}

StudentWorld* Actor::getWorld()
{
    return m_StudentWorld;
}

    //set to false by default.
bool Actor::isenemy()
{
    return false;
}

bool Actor::isfoodorpit()
{
    return false;
}
    //set to false by default.
bool Actor::isprojectile()
{
    return false;
}

Actor::~Actor()
{
}

///////
//////DamageableActor implementation///
//////



DamageableActor::DamageableActor(int imageID, double startX, double startY, Direction dir, int depth, double size, StudentWorld* studentworld, double hp)
:Actor(imageID, startX, startY, dir, depth, size, studentworld)
{
    m_hp = hp;
}

double DamageableActor::hp()
{
    return m_hp;
}

    //only socrates can gain health in this game.
void DamageableActor::gainhp(double amt)
{
    m_hp += amt;
    if (m_hp > 100)
        m_hp = 100;
}

    //losehp varies depending on actor
void DamageableActor::losehp(double amt)
{
    m_hp -= amt;
}

DamageableActor::~DamageableActor()
{
}



///////
//////Socrates implementation///
//////

Socrates::Socrates(StudentWorld* studentworld)
: DamageableActor(IID_PLAYER, 0, 128, 0, 0, 1, studentworld, 100)
//DamageableActor(<#int imageID#>, <#double startX#>, <#double startY#>, Direction dir, <#int depth#>, <#double size#>, <#StudentWorld *studentworld#>, <#double hp#>)
{
    m_spraycharges = MAXSPRAYS;
    m_flamecharges = MAXFLAMES;
}

void Socrates::doSomething()
{
    if (!isalive())
        return;
    int ch;
    if (getWorld() -> getKey(ch))
    {
        //user hit a key during this tick!
        switch (ch) {
            case KEY_PRESS_LEFT:
            {
                //move counterclockwise
                double prev_theta = (getDirection()+180) % 360;
                double new_theta = prev_theta + 5;
                moveAroundCircle(new_theta);
                setDirection(getDirection()+5);
                break;
            }
                
            case KEY_PRESS_RIGHT:
            {
                //move clockwise
                double prev_theta = (getDirection()+180) % 360;
                double new_theta = prev_theta - 5;
                moveAroundCircle(new_theta);
                setDirection(getDirection()-5);
                break;
            }
//            case KEY_PRESS_SPACE:
//            {
//                if (spraycharges() > 0)
//                {
//                    //TODO: create sprayproj object
//                    SprayProj* newSpray = new SprayProj();
//                }
//                getWorld()
//            }

        }
    }
    
    //always increase number of spray charges by 1 if currentcount is less than max.
    if (spraycharges() < MAXSPRAYS)
        m_spraycharges++;

}

void Socrates::moveAroundCircle(double angle)
{
    double new_x = VIEW_RADIUS+VIEW_RADIUS*cos(angle*(4*atan(1)/180));
    double new_y = VIEW_RADIUS+VIEW_RADIUS*sin(angle*(4*atan(1)/180));
    moveTo(new_x, new_y);
}

int Socrates::spraycharges()
{
    return m_spraycharges;
}

int Socrates::flamecharges()
{
    return m_flamecharges;
}

void Socrates::increaseflamecharges()
{
    m_flamecharges += 5;
}

Socrates::~Socrates()
{
}


///////
//////Dirt implementation///
//////

Dirt::Dirt(StudentWorld* studentworld, double startX, double startY)
: Actor(IID_DIRT, startX, startY, 0, 1, 1, studentworld)
//int m_imageID, double startX, double startY, Direction Dirt, int m_depth, double size, StudentWorld *studentworld
{
}
    //dirt does nothing
void Dirt::doSomething()
{
}

Dirt::~Dirt()
{
}

///////
//////Food implementation///
//////

Food::Food(StudentWorld* studentworld, double startX, double startY)
: Actor(IID_FOOD, startX, startY, 0, 1, 1, studentworld)
{
}

void Food::doSomething()
{
}

bool Food::isfoodorpit()
{
    return true;
}

Food::~Food()
{
}

///////
//////Pit implementation///
//////

Pit::Pit(StudentWorld* studentworld, double startX, double startY)
: Actor(IID_PIT, startX, startY, 0, 1, 1, studentworld)
{
    m_regsalm = 5;
    m_aggsalm = 3;
    m_ecoli = 2;
}

void Pit::doSomething()
{
    if (m_regsalm == 0 && m_aggsalm == 0 && m_ecoli == 0)
        die();
    else
    {
        if (randInt(1, 50) == 1)
        {
            int bacterium = randInt(1, 3);
            switch (bacterium) {
                case 1:
                {
//                    RegSalmonella* newregsalmonella = new RegSalmonella(getWorld(), , double startY)
                }
                    break;
                    
                default:
                    break;
            }
        }
    }
}

bool Pit::isfoodorpit()
{
    return true;
}

Pit::~Pit()
{
}

////////////////////////////////
//////DecayitemS implementation///
////////////////////////////////

Decayitem::Decayitem(int imageID, double startX, double startY, StudentWorld* studentworld)
: Actor(imageID, startX, startY, 0, 1, 1, studentworld)
{
    m_lifetime = fmax( rand()%(300 - 10*(studentworld->getLevel())), 50);
}

bool Decayitem::isexpired()
{
    if (m_lifetime <= 0)
        return true;
    
    return false;
}

void Decayitem::checkcollision(int pts)
{
    if (getWorld()->iscollidingSocrates(this))  //the item collided with the Socrates
    {
        getWorld()->increaseScore(pts);

        die();

        getWorld()->playSound(SOUND_GOT_GOODIE);

        applyeffect();
    }
}

void Decayitem::reducelifetime()
{
    m_lifetime--;
}


Decayitem::~Decayitem()
{
}
   
////////////////////////////////
//////Restorehealthgoods implementation///
////////////////////////////////

RestorehealthGoods::RestorehealthGoods(StudentWorld* studentworld, double startX, double startY)
: Decayitem(IID_RESTORE_HEALTH_GOODIE, startX, startY, studentworld)
{
}

void RestorehealthGoods::doSomething()
{
    if (!isalive())
        return;
    
    checkcollision(250);

    reducelifetime();
    
    if (isexpired())
        die();
}

void RestorehealthGoods::applyeffect()
{
    getWorld()->getSocrates()->gainhp(100);
}

RestorehealthGoods::~RestorehealthGoods()
{
}

////////////////////////////////
//////Flamethowergood implementation///
////////////////////////////////

FlameThrowerGoods::FlameThrowerGoods(StudentWorld* studentworld, double startX, double startY)
: Decayitem(IID_FLAME_THROWER_GOODIE, startX, startY, studentworld)
{
}

void FlameThrowerGoods::doSomething()
{
    if (!isalive())
        return;
    
    checkcollision(300);

    reducelifetime();
    
    if (isexpired())
        die();
}

void FlameThrowerGoods::applyeffect()
{
    getWorld()->getSocrates()->increaseflamecharges();
}

FlameThrowerGoods::~FlameThrowerGoods()
{
}

////////////////////////////////
//////Extralifegood implementation///
////////////////////////////////

ExtraLifeGoods::ExtraLifeGoods(StudentWorld* studentworld, double startX, double startY)
: Decayitem(IID_EXTRA_LIFE_GOODIE, startX, startY, studentworld)
{
}

void ExtraLifeGoods::doSomething()
{
    if (!isalive())
        return;
    
    checkcollision(500);

    reducelifetime();
    
    if (isexpired())
        die();
}

void ExtraLifeGoods::applyeffect()
{
    getWorld()->incLives();
}

ExtraLifeGoods::~ExtraLifeGoods()
{
}

////////////////////////////////
//////Fungus Implementation///
////////////////////////////////
Fungus::Fungus(StudentWorld* studentworld, double startX, double startY)
:Decayitem(IID_FUNGUS, startX, startY, studentworld)
{
}

void Fungus::doSomething()
{
    if (!isalive())
        return;
    
    checkcollision(-50);

    reducelifetime();
    
    if (isexpired())
        die();
}

bool Fungus::isenemy()
{
    return true;
}

void Fungus::applyeffect()
{
    getWorld()->getSocrates()->losehp(20);
}

Fungus::~Fungus()
{
}
////////////////////////////////
//////Enemy implementation///
////////////////////////////////

Enemy::Enemy(int imageID, double startX, double startY, StudentWorld* studentworld, double hp)
: DamageableActor(imageID, startX, startY, 90, 0, 1, studentworld, hp)
{
}

bool Enemy::isenemy()
{
    return true;
}

Enemy::~Enemy()
{
}


////////////////////////////////
//////Regsalmonella implementation///
////////////////////////////////


RegSalmonella::RegSalmonella(StudentWorld* studentworld, double startX, double startY)
: Enemy(IID_SALMONELLA, startX, startY, studentworld, 4)
{
}
    
void RegSalmonella::doSomething()
{
}
    
RegSalmonella::~RegSalmonella()
{
}

////////////////////////////////
//////AggSalmonella implementation///
////////////////////////////////
AggSalmonella::AggSalmonella(StudentWorld* studentworld, double startX, double startY)
: Enemy(IID_SALMONELLA, startX, startY, studentworld, 10)
{
}
    
void AggSalmonella::doSomething()
{}
    
AggSalmonella::~AggSalmonella()
{}

////////////////////////////////
//////Ecoli implementation///
////////////////////////////////
EColi::EColi(StudentWorld* studentworld, double startX, double startY)
: Enemy(IID_ECOLI, startX, startY, studentworld, 5)
{
}
    
void EColi::doSomething()
{
}
    
EColi::~EColi()
{
}
